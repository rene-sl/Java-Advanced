package cardswithpower;

public enum CardPower {
    CLUBS(0),
    DIAMONDS(13),
    HEARTS(26),
    SPADES(39),
    ;


    private int valuePower;

    CardPower(int valuePower) {
        this.valuePower = valuePower;
    }

    public int getValuePower() {
        return valuePower;
    }
}
