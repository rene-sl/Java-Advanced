package cardswithpower;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String inputSuit = scanner.nextLine();
        String inputPower = scanner.nextLine();

        CardSuit suit = CardSuit.valueOf(inputSuit);
        CardPower power = CardPower.valueOf(inputPower);

        Card card = new Card(suit, power);
        System.out.println(card.toString());
    }
}
