package cardswithpower;

public class Card {
     private CardSuit suit;
     private CardPower power;


     public Card(CardSuit suit, CardPower power){
         this.suit=suit;
         this.power=power;

     }

     private int getPower(){
         return suit.getValue()+power.getValuePower();
     }

     @Override
    public String toString(){
         return String.format("Card name: %s of %s; Card power: %d%n", this.suit,
                 this.power, this.getPower());
     }
}
