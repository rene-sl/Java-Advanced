package jedigalaxy;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] dimensions = Arrays.stream(scanner.nextLine().split(" "))
                .mapToInt(Integer::parseInt).toArray();
        int rows = dimensions[0];
        int cols = dimensions[1];

        int[][] field = new int[rows][cols];

        int value = 0;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                field[i][j] = value++;
            }
        }

        String command = scanner.nextLine();
        long sum = 0;
        while (!command.equals("Let the Force be with you")) {
            int[] playerDirection = Arrays.stream(command.split(" ")).mapToInt(Integer::parseInt).toArray();
            int[] evilDirection = Arrays.stream(scanner.nextLine().split(" ")).mapToInt(Integer::parseInt).toArray();
            int startPointEvil = evilDirection[0];
            int endPointEvil = evilDirection[1];

            while (startPointEvil >= 0 && endPointEvil >= 0) {
                if (startPointEvil < field.length && endPointEvil < field[0].length) {
                    field[startPointEvil][endPointEvil] = 0;
                }
                startPointEvil--;
                endPointEvil--;
            }

            int startPointPlayer = playerDirection[0];
            int endPointPlayer = playerDirection[1];

            while (startPointPlayer >= 0 && endPointPlayer < field[1].length) {
                if (startPointPlayer < field.length && endPointPlayer >= 0 && endPointPlayer < field[0].length) {
                    sum += field[startPointPlayer][endPointPlayer];
                }

                endPointPlayer++;
                startPointPlayer--;
            }

            command = scanner.nextLine();
        }

        System.out.println(sum);


    }
}

