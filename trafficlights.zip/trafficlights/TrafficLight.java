package trafficlights;

public enum TrafficLight {
    RED,
    GREEN,
    YELLOW,
    ;

}
