package trafficlights;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TrafficLight [] trafficLights = Arrays.stream(scanner.nextLine().split("\\s+"))
                .map(TrafficLight::valueOf).toArray(TrafficLight[]::new);

        int size = Integer.parseInt(scanner.nextLine());

        TrafficLight [] light = TrafficLight.values();

        while(0<size){
            for (int i=0; i< trafficLights.length; i++) {
                int index = (trafficLights[i].ordinal()+1)%light.length;

                trafficLights[i] = light[index];
                System.out.print(trafficLights[i].toString()+" ");
            }
            System.out.println();

            size--;
        }

    }
}
